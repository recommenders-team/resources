cd ../../tests/resources/deeprec/dkn/MINDsmall/scripts/
python build_train_valid.py
python build_doc_features.py
